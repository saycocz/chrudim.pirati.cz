---
layout: post
categories: CLANKY
title: Otevření Pirátského centra CPICE
date: 2016-05-1T10:44:00+02:00
tags: CPICE 
author: Piráti Chrudim
image: assets/img/articles/2016/chrudim.jpg
---

Česká Pirátská Strana - Krajské sdružení Pardubice otevírá v Chrudimi své centrum.  
Slavnostní otevření je v **pátek 13.5.2016(17:00-19:00)** v Radoušově ulici.


Na místě se můžete těšit na:
----------------------------
* Veřejnou ledničku
* Otevření veřejné knihovny
* Freeshop
* Otevřeny počítač
* Občerstvení
* Hudbu
