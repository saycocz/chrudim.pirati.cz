---
layout: post
category: CLANKY
title: Přímý přenos 11. zasedání zastupitelstva města Chrudim
date: 2016-01-25T10:44:00+02:00  
tags: zastupitelstvo 
author: Piráti Chrudim
image: assets/img/articles/2016/chrudim.jpg
---

Dne 25.1.2016 od 16:00 se uskuteční 11. zasedání zastupitelstva města Chrudim.
Zasedání bylo svoláno v řádném termínu.
Minulé zasedání jsme bohužel z časových důvodů nepřenášeli, ale toto nadcházející Vám přineseme prostřednictvím
online přenosu. 

Body jednání:
-------------
* Návrh rozpočtového opatření č. 1/2016 ke schválenému rozpočtu města Chrudim na rok 2016 
* Komunitní plán sociálních služeb ve městě Chrudim 2016 - 2018 
* Dodatek ke smlouvě o poskytnutí přímé dotace - Šance pro Tebe, o.s. 
* Přísedící Okresního soudu v Chrudimi 
* Plán odpadového hospodářství města Chrudim 
* Návrh na bezúplatný převod majetku od ÚZSVM 
* Návrh na převod nemovitosti v k. ú. Medlešice 
* Smlouva o přípravě, výstavbě a provozu vodárenské infrastruktury, akce „Komunikace a inženýrské sítě v lokalitě Markovice u kostela 1. etapa“ 
* Smlouva o přípravě, výstavbě a provozu vodárenské infrastruktury, akce Výstavba vodovodu v ul. "Nádražní III", Medlešice 
* Informace o činnosti Rady města Chrudim 
* Všeobecná rozprava 


Podklady pro jednaní zastupitelstva lze nalést na [na stránkách města Chrudim] [7].
Stream ze zasedání bude zprostředkován pomocí kanálu na *youtube.com*. 

#####Odkaz na přímý přenos:
[server youtube.com] [6]


Informační kanály:
------------------
* [Oficiální stránka PKS Pardubického kraje][1]
* [Piráti.cz][2]
* [Internetové fórum pirátů][3]
* [Facebooková stránka PK][4]
* [Facebooková stránka Chrudimských pirátů][5]
* [Youtube kanál České Pirátské Strany][8]
* [Zpráva na webu města Chrudim][9]

[1]: https://www.pirati.cz/regiony/pardubicko/start
[2]: https://www.pirati.cz
[3]: https://forum.pirati.cz
[4]: https://www.facebook.com/pages/Pir%C3%A1ti-Pardubick%C3%BD-kraj/161396423900274?ref=ts&fref=ts
[5]: https://www.facebook.com/CeskaPiratskaStranaChrudim?fref=ts
[6]: https://www.youtube.com/watch?v=NNgnTUkex78
[7]: http://www.chrudim-city.cz/eTED/%28S%28hdtgpm3k2e4yko55s2xvkqji%29%29/tedprgjed.aspx?id=3240
[8]: https://www.youtube.com/channel/UC_zxYLGrkmrYazYt0MzyVlA
[9]: http://www.chrudim.eu/mesto/aktualne.html/14_3119-25.-ledna-zaseda-zastupitelstvo-mesta
