---
layout: post
category: CLANKY
title: Zahájení kampaně - komunální volby 2018
date: 2018-06-05T00:00:00+01:00  
tags: 
    - Komunalni-volby
author: Piráti Chrudim

image: assets/img/articles/2018/.png #751x422
---

## Dobydou napotřetí Piráti chrudimské zastupitelstvo? „Věříme si,“ říká lídr chrudimských Pirátů Pavel Štěpánek

Jaká je pirátská vize pro Chrudimi? Na tuto otázku dostanete na tiskové konferenci odpověď ve čtvrtek 9. 6. 2018 od 9:00 v chrudimské Radoušově ulici při příležitosti představení pirátského programu a čelních kandidátů do Zastupitelstva města. Zároveň bylo při této příležitosti „znovu otevřeno“ Chrudimské Pirátské centrum.

### Nestíháte se zúčastnit? Na [Facebooku](https://www.facebook.com/CeskaPiratskaStranaChrudim/?ref=br_rs) chrudimských Pirátů bude od 9:00 přímý přenos. 

 >„Máme takovou vizi pro Chrudim a vytyčeno několik okruhů, které pokrývají, podle nás, nejpalčivější problémy města. Jedná se například o transparenci hospodaření města, digitalizaci a modernizaci, ale i vodohospodářství a ekologii. Věříme si, že tímto programem zaujmeme dostatek spoluobčanů a získáme alespoň 15% hlasů“ 
,říká lídr chrudimských Pirátů.

### Co máme v plánu?

Každý z čelních kandidátů do zastupitelstva je zároveň garantem jednoho až dvou programových bodů, které chce ve městě prosadit. Jednotlivé body programu a konkrétní kroky k jeho naplnění budou prezentovat jednotliví garanti a po skončení prezentace bude prostor pro dotazy. Druhý muž chrudimské kandidátky Bc. Daniel Lebduška tak bude například prezentovat vizi ohledně budoucnosti chrudimské vody, trojka kandidátky Ing. Aleš Nunvář bude prezentovat svou vizi ohledně životního prostředí a veřejných prostranství či se můžete těšit na téma otevřenost a participace občanů, které představí Zdeňek Kubala. 

Akce proběhne v Pirátském centru, které poprvé otevřelo své dveře již v roce 2016 a v letošním roce prošlo úpravami, aby se stalo příjemným místem pro setkávání členů pirátské strany se spoluobčany. Navíc si zde svou kancelář zřídil lídr pro chrudimské komunální volby Štěpánek, který je zároveň koordinátor pirátů Pardubického kraje.

