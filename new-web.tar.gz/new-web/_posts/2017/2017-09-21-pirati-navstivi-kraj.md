---
layout: post
category: CLANKY
title: Piráti navštíví do voleb přes 30 měst a obcí v Pardubickém kraji
date: 2017-09-21T20:19:00+02:00  
tags: kampaň-volby2017
author: Piráti Pardubického kraje
image: assets/img/articles/2017/kampan_pce.png   #751x422 pixelu
---


Volební lídr Pirátské strany v Pardubickém kraji **Mikuláš Ferjenčík** má v plánu do letošních sněmovních voleb navštívit všechny obce v kraji,
 které mají nad dva tisíce obyvatel a některé dokonce opakovaně. Udělá kontaktní kampaň, která v historii Pirátské strany v Pardubickém kraji nemá obdoby.

Pirátská kampaň je založena na dobrovolnické práci s minimálními náklady na tradiční marketing, kde jiné strany utápí horentní částky.
 Piráti se vydávají cestou moderní online komunikace – především přes sociální sítě – a rozsáhlé účasti na ulicích a náměstích měst a městeček kraje.

Několik předvolebních meetingů již proběhlo v srpnu tohoto roku, od začátku září naplno běží šnůra předvolebních setkání pirátského lídra v jednotlivých
 městech pardubického kraje s voliči – například v *Chrudimi, Vysokém Mýtě, Pardubicích, Lanškrouně, Letohradě, Holicích a Přelouči*, 
kde Mikuláš Ferjenčík vystudoval gymnázium. Další větší města jako jsou například *Svitavy, Litomyšl, Česká Třebová* mají Piráti v plánu navštívit do konce září.

>Cítím, že máme na to, se do Sněmovny dostat a provětrat tamní zatuchlou atmosféru – věřím, že k celostátnímu cíli Pirátů, což je 10 % hlasů, přispějeme odpovídajícím dílem
, říká Mikuláš Ferjenčík a doplňuje: „Pirátům věřím především díky nasazení našich členů a podporovatelů. Tento rok s volebním potenciálem **12%**,
 který zveřejnila Česká televize, plujeme do sněmovny plnou parou.“

Harmonogram Pirátské kampaně v Pardubickém kraji naleznete  [zde][1]


[1]: https://pardubicky.pirati.cz/plavba/
