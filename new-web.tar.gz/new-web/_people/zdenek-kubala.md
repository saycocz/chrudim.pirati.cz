---
uid: zdenek.kubala
name:     Zdeněk Kubala      		# běžně používáné jméno
fullname: Zdeněk Kubala		# jméno s tituly etc.
category:                 		# kategorie: rp, praha, vary, hradec, jmk, senat
- pak
- kppak
- kandidat-chrudim-2018
img: people/zdenek-kubala.jpg           # 165 x 220
description: 1. místopředseda KS Pardubický kraj, zástupce vedoucího technického odboru # kratký popis, max 160 znaků
ordpak: 4
ordkomunal2018: 4
mail:
- zdenek.kubala@pirati.cz
mob: 

profiles:
  github: djz88
  facebook: 
  twitter:
  linkedin:
---
Člen komise pro sport a mládež rady města Chrudim.

Je členem Pirátské strany. Řadí se mezi neortodoxní vimaře.  
Narozen a s občasnými pracovními zastávkami v Brně a Praze přes 30 let žijící v Chrudimi.  
Vystudoval SOŠ v Hradci Králové, poté přerušil studium na Univerzitě Pardubice obor Informační technologie, který jej zcela nenaplňoval.  

Pracovní zkušenosti nabral v několika národních i nadnárodních společnostech a to zejména v oblastech správy sítí a operačních systému, podílel se na projektech týkající se informačních systémů, infrastruktury či služeb a v neposlední řadě návrhu IT řešení preferující LINUX a open source. Aktuálně je zaměstnán jako inženýr kvality v softwarové firmě, ;IT konzultant na volné noze a přednáší na Open Source konferencích. 

Zajímá se o nové technologie, které rád prozkoumává. Jeho vášní je operační systém LINUX a open source všeobecně. Mimojiné ho baví fotbal, hokej, paintball a rád relaxuje na kolečkových bruslích či při běhu. Jeho práce je zároveň i jeho koníčkem.

