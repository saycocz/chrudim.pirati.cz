---
uid: nikola.stepankova
name:     Nikola Štěpánková      		# běžně používáné jméno
fullname: Nikola Štěpánková		# jméno s tituly etc.
category:                 		# kategorie: rp, praha, vary, hradec, jmk, senat
- pak
- kandidat-chrudim-2018
img: people/nikola-stepankova.jpg           # 165 x 220
description: ćlenka Pirátské strany  a sociální komise rady města Chrudim # kratký popis, max 160 znaků
ordpak: 5
ordkomunal2018: 5
mail:
- nikola.stepankova@pirati.cz
mob: 
profiles:
  github:
  facebook: 
  twitter:
  linkedin:
---
Vystudovala gymnázium a nedostudovala Fakultu humanitních studií Karlovy univerzity, z důvodu odjezdu na Island, kde se stala součástí projektu vlády – zalesnění země a dále pracovala v zimním středisku. Zkušenosti má především v oblasti prodeje. Před nástupem na rodičovskou dovolenou, pracovala jako specialistka firemní péče u mobilního operátora. Příležitostně hodnotí projekty pro nadační fond. A nyní zasedá v Komisi pro životní prostředí města Chrudimi. Angažuje se v aktivitách souvisejících s kulturou a v době studia pracovala jako dobrovolnice pro charitu. Jejím zájmem je především pole dance, jízda na kole, snowboarding, fotografování.
