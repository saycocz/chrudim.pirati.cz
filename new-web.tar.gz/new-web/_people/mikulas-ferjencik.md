---
uid: mikulas.ferjencik
name:     Mikuláš Ferjenčík  	# běžně používáné jméno
fullname: Mikuláš Ferjenčík  	# jméno s tituly etc.
category:                 	# kategorie: rp, praha, vary, hradec, jmk, senat
- pardubice
- mo-contact
- poslanec-pce
img: people/mikulas-ferjencik.jpg   # 165 x 220
description: Poslanec Parlamentu ČR za Pardubický kraj, vedoucí mediálního odboru Pirátů             	# kratký popis, max 160 znaků
ordpak: 
mail:
- mikulas.ferjencik@pirati.cz
mob:			  +420 737 943 770
profiles:
  github:       https://github.com/mifer
  facebook:     https://www.facebook.com/mikfer
  twitter: 		  https://twitter.com/Mikiferjencik
  flickr:		  https://www.flickr.com/search/?user_id=68741528%40N03&sort=date-taken-desc&view_all=1&text=mikul%C3%A1%C5%A1%20ferjen%C4%8D%C3%ADk
ordpraha: 3
ordkontakty: 1
---

Mikuláš Ferjenčík (19. března 1987) je zastupitel hlavního města Prahy za Pirátskou stranu. Pochází z Českých Budějovic, mládí strávil v Cholticích u Pardubic. Studoval na gymnáziu v Přelouči Díky stipendiu nadace Open Society Fund dva roky strávil na Brentwood School v Essexu ve Velké Británii, kde složil i tamní maturitní zkoušku. Po necelých dvou letech následně strávených na Matematicko-fyzikální fakultě Univerzity Karlovy se vydal na Fakultu strojní ČVUT. Od února 2013 do srpna 2013 působil jako koordinátor dobrovolníků v protikorupční kampani Rekonstrukce státu. V Pirátské straně koordinoval protesty proti smlouvě ACTA, stejně jako kampaň Internet bez cenzury. Pomohl zabránit zavedení turniketů v pražském metru a výrazně přispěl k zapojení České pirátské strany do mezinárodního Pirátského hnutí.

V pražském zastupitelstvu se věnuje převážně oblasti územního plánování. Upozorňuje na machinace se změnami územního plánu; zastavování volných ploch developery, stejně jako obchody některých politiků, které se prostřednictvím změn územního plánu realizují.
