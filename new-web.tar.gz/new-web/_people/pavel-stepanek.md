---
uid: pavel.stepanek
name:     Pavel Štěpánek  	# běžně používáné jméno
fullname: Pavel Štěpánek  	# jméno s tituly etc.
category:                 	# kategorie: rp, praha, vary, hradec, jmk, senat
- pak
- koordinatori
- kandidat-chrudim-2018
img: people/pavel-stepanek.jpg   # 165 x 220
description: koordinátor krajského sdružení pro Pardubický kraj # kratký popis, max 160 znaků
ordpak: 
ordkomunal2018: 1
mail:
- pavel.stepanek@pirati.cz
mob:			  
profiles:
  github:                 
  facebook: 		  
  twitter: 		  
  flickr:     		  
---

Pavel Štěpánek (* 24. září 1985, Chrudim) je předseda krajského sdružení Pardubického kraje. Vystudoval obor veřejné správy. Pracoval v několika zaměstnáních, kde se věnoval převážně mládeži. Byl streetworker, instruktor snowboardingu a adrenalinových aktivit nebo nízkoprahových zařízeních. V současnosti pracuje „na volné noze“, tedy jako živnostník ve více oblastech.

Angažuje se v aktivitách souvisejících s kulturou nebo se sociální prací. Jeho zájmy jsou především adrenalinový sport, hudba nebo filosofie a otázka lidské svobody a udržitelného rozvoje.
