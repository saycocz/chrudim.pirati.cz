---
uid: daniel.lebduska
name:     Daniel Lebduška               # běžně používáné jméno
fullname: Bc. Daniel Lebduška           # jméno s tituly etc.
category:                               # kategorie: rp, praha, vary, hradec, jmk, senat
- pak
- kandidat-chrudim-2018
img: people/daniel-lebduska.jpg           # 165 x 220
description: člen Pirátské strany, volební manažer pro Chrudim # kratký popis, max 160 znaků
ordpak: 2
ordkomunal2018: 2
mail:
- daniel.lebduska@pirati.cz
mob:
profiles:
  github:
  facebook: https://www.facebook.com/lebduska.daniel
  twitter:
  linkedin:
---

__Krajský koordinátor pro Pard. kraj__


Do strany vstoupil v lednu 2017 a od února 2017 je Krajským volebním koordinátorem pro Pardubický kraj. 

_* 30. září 1989 Chrudim_

Daniel vyrůstal v Chrudimi a studoval v Praze. Nyní opět žije v Chrudimi.

Od roku 2013 působí v marketingu na různých pozicích - nyní jako marketingový manažer ve společnosti IPC Team - zabývá se především online marketingem, okrajově i offline marketingem. Zároveň se pomáhá s marketingem dalším firmám ve volném čase jako freelancer.

Politický postoj: „S názory #Pirátskástrana dlouhodobě souhlasím a největší problém české politiky je v tom, že to není politika, ale hraní si na ni. Nějak stále věřím tomu, že republika je od „res publica“ a tak by neměl platit precedens, který si mnoho lidí uchovává a nevědomky předává svým dětem - „nerušit, vládneme“ nechci, díky … Jo a nevadí mi cikáni, ani uprchlíci - ti naši zemi obírají o podstatně méně, než předem domluvená výběrová řízení pro jednoho dodavatele v součtu všech státních zakázek v řádech bambilionů ročně.“

